Ext.onReady(function(){


    var viewport = new Ext.Viewport({
        layout            : "border",
        items: [{
            region        : "center",
			contentEl     : 'center-div',
            title         : "Administrative Portal",
			autoScroll    : true,
        }, {
            region        : "north",
            height        : 75
        }, {
            region        : "south",
            title         : "North Carolina State University Career Center"
        }, {
            region        : "west",
            title         : "Navigation",
			contentEl     : 'west-div',
            width         : 165,

        }]
    });
    
    
});
