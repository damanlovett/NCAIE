<?php
class WidgetsController extends AppController {

	var $name = 'Widgets';
	var $helpers = array('Html', 'Form');

    function someAction() {
    
    }

}
?>