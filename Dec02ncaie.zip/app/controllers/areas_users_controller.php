<?php
class AreasUsersController extends AppController {

	var $name = 'AreasUsers';
	var $scaffold;
}
?>