<?php
class Section extends AppModel {

    var $name = 'Section';
    var $useTable = 'dropdowns';

}
?>