<?php
class Widget extends AppModel {

	var $name = 'Widget';
	
	var $useTable = false;
	
}
?>