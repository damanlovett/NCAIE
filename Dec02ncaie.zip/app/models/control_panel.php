<?php
class ControlPanel extends AppModel {

	var $name = 'ControlPanel';

    var $useTable = false;
 

}
?>