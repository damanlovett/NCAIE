<?php

//Export to Excel Server Behavior
if (isset($_GET['reps'])&&($_GET['reps']=="yes")){
$lang=(strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'],",")===false)?$_SERVER['HTTP_ACCEPT_LANGUAGE']:substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'],","));
$semi_array=array("af","zh-hk","zh-mo","zh-cn","zh-sg","zh-tw","fr-ch","de-li","de-ch","it-ch","ja","ko","es-do","es-sv","es-gt","es-hn","es-mx","es-ni","es-pa","es-pe","es-pr","sw");
$delim=(in_array($lang,$semi_array) || substr_count($lang,"en")>0)?",":";";
$output="";
$include_hdr="1";
if($include_hdr=="1"){
    $totalColumns_rsReps=mysql_num_fields($rsReps);
    for ($x=0; $x<$totalColumns_rsReps; $x++) {
        if($x==$totalColumns_rsReps-1){$comma="";}else{$comma=$delim;}
        $output = $output.(ereg_replace("_", " ",mysql_field_name($rsReps, $x))).$comma;
    }
    $output = $output."\r\n";
}

do{$fixcomma=array();
    foreach($row_rsReps as $r){array_push($fixcomma,ereg_replace($delim,"¸",$r));}
    $line = join($delim,$fixcomma);
    $line=ereg_replace("\r\n", " ",$line);
    $line = "$line\n";
    $output=$output.$line;}while($row_rsReps = mysql_fetch_assoc($rsReps));
header("Content-Type: application/xls");
header("Content-Disposition: attachment; filename=reps_report.csv");
header("Content-Type: application/force-download");
header("Cache-Control: post-check=0, pre-check=0", false);
echo $output;
die();
}
?>