    tinyMCE.init({
        theme : "advanced",
        mode : "textareas",
        convert_urls : false
    }); 