<?php
class User extends AppModel {

	var $name = 'User';
	var $hasOne = 'Profile';

}
?>