<?php
class Volunteering extends AppModel {

	var $name = 'Volunteering';
	var $useTable = 'dropdowns';

}
?>