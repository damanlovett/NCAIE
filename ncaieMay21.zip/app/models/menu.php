<?php
class Menu extends AppModel {

	var $name = 'Menu';
	var $useTable = 'dropdowns';

}
?>