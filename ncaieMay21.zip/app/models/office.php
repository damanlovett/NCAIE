<?php
class Office extends AppModel {

	var $name = 'Office';
	var $useTable = 'dropdowns';
	var $sampletest = null;
	
	function sampletest() {
		echo "Eddie";
	}

}
?>