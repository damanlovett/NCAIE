<?php
class Position extends AppModel {

	var $name = 'Position';
	var $useTable = 'dropdowns';

}
?>