<?php
class NcaiesController extends AppController {

	var $name = 'Ncaies';
	var $helpers = array('Html', 'Form');

	function index() {
		$this->Ncaie->recursive = 0;
		$this->set('ncaies', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Ncaie.', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->set('ncaie', $this->Ncaie->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Ncaie->create();
			if ($this->Ncaie->save($this->data)) {
				$this->Session->setFlash(__('The Ncaie has been saved', true));
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The Ncaie could not be saved. Please, try again.', true));
			}
		}
		$sections = $this->Ncaie->Section->find('list');
		$users = $this->Ncaie->User->find('list');
		$this->set(compact('sections', 'users'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Ncaie', true));
			$this->redirect(array('action'=>'index'));
		}
		if (!empty($this->data)) {
			if ($this->Ncaie->save($this->data)) {
				$this->Session->setFlash(__('The Ncaie has been saved', true));
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The Ncaie could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Ncaie->read(null, $id);
		}
		$sections = $this->Ncaie->Section->find('list');
		$users = $this->Ncaie->User->find('list');
		$this->set(compact('sections','users'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Ncaie', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Ncaie->del($id)) {
			$this->Session->setFlash(__('Ncaie deleted', true));
			$this->redirect(array('action'=>'index'));
		}
	}


	function admin_index() {
		$this->Ncaie->recursive = 0;
		$this->set('ncaies', $this->paginate());
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Ncaie.', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->set('ncaie', $this->Ncaie->read(null, $id));
	}

	function admin_add() {
		if (!empty($this->data)) {
			$this->Ncaie->create();
			if ($this->Ncaie->save($this->data)) {
				$this->Session->setFlash(__('The Ncaie has been saved', true));
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The Ncaie could not be saved. Please, try again.', true));
			}
		}
		$sections = $this->Ncaie->Section->find('list');
		$users = $this->Ncaie->User->find('list');
		$this->set(compact('sections', 'users'));
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Ncaie', true));
			$this->redirect(array('action'=>'index'));
		}
		if (!empty($this->data)) {
			if ($this->Ncaie->save($this->data)) {
				$this->Session->setFlash(__('The Ncaie has been saved', true));
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The Ncaie could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Ncaie->read(null, $id);
		}
		$sections = $this->Ncaie->Section->find('list');
		$users = $this->Ncaie->User->find('list');
		$this->set(compact('sections','users'));
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Ncaie', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Ncaie->del($id)) {
			$this->Session->setFlash(__('Ncaie deleted', true));
			$this->redirect(array('action'=>'index'));
		}
	}

}
?>